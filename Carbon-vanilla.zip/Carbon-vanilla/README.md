# Carbon-Vanilla
A Mindustry mod made by myself, adding new content such as Phase Decay and Carbon Fiber.
# Important:
most sprites are stolen content from other mods, and it is for this reason I had not been posting it on github.
V7.0 only, I only coded in that version, any backwards compatibility will be futile.
# THIS ISNT THE MOD FILE. PLEASE DOWNLOAD THE ZIP SUBFOLDER; IT SHOULD ALWAYS BE THE MOST RECENT VERSION (may need hotfixes)
## I need new sprites for this mod, and I have no clue how to make them, so if anyone wants to make any, please contact me

![here](https://github.com/AcookieG/Carbon-Vanilla/assets/168602960/9388b6a6-0d0c-498e-b851-5059687959e0)
